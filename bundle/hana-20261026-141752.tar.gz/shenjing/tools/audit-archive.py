#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""档案体检：拿"最新的整包"当对照组，看现在桌上的档案少了什么。

为什么要有这个：
  2026-10-26 12:36 整棵 shenjing/ 被搬过一次，43 个文件都跟过来了，
  **只有 journal/2026-10-26.md 一个文件漏了**。备份没报错（push 一直是通的），
  我自己也没发现——直到下午醒来去翻日记，看见早上那 109 行不在。

  丢一个文件不需要系统出故障，只要一次搬运时手滑。
  所以要有一样东西，每次醒来跑一遍，能说出"少了哪个"，而且少的时候会失败。

判据（可判定，不是形容词）：
  最新整包里存在、而当前档案里不存在的文件 → 报出来，exit 2。
  内容不同但去掉行尾符以后相同的 → 只算"换了行尾"，不算差异，不报。
  内容真的不同 → 报出来，exit 3（可能是正常的后来修改，也可能是被旧版本盖了，要人看一眼）。

用法：
  python F:\\小鲸\\shenjing\\tools\\audit-archive.py            # 拿最新整包比
  python F:\\小鲸\\shenjing\\tools\\audit-archive.py --against <tar.gz|目录>
  python F:\\小鲸\\shenjing\\tools\\audit-archive.py --selftest # 造一个反例，确认它真会报
"""
import argparse
import glob
import hashlib
import os
import sys
import tarfile

ARCHIVE = os.environ.get("SHENJING_ARCHIVE", r"F:\小鲸\shenjing")
BUNDLE_DIR = os.environ.get("SHENJING_BUNDLE_DIR", r"F:\小鲸\bundle")
IGNORE = {"tools/audit-archive.py"}  # 我自己这个文件；整包里可能还没有


def read_bundle(path):
    """返回 {相对路径: bytes}，相对路径以 shenjing/ 为根。"""
    out = {}
    if os.path.isdir(path):
        root = path
        if os.path.isdir(os.path.join(root, "shenjing")):
            root = os.path.join(root, "shenjing")
        for base, _, files in os.walk(root):
            for f in files:
                p = os.path.join(base, f)
                rel = os.path.relpath(p, root).replace("\\", "/")
                out[rel] = open(p, "rb").read()
        return out
    with tarfile.open(path, "r:gz", encoding="utf-8") as t:
        for m in t.getmembers():
            if not m.isfile():
                continue
            name = m.name
            if name.startswith("shenjing/"):
                rel = name[len("shenjing/"):]
            elif "shenjing/" in name:
                rel = name.split("shenjing/", 1)[1]
            else:
                continue
            out[rel] = t.extractfile(m).read()
    return out


def read_current(root):
    out = {}
    for base, _, files in os.walk(root):
        for f in files:
            p = os.path.join(base, f)
            rel = os.path.relpath(p, root).replace("\\", "/")
            out[rel] = open(p, "rb").read()
    return out


def norm(data):
    return data.replace(b"\r\n", b"\n")


def newest_bundle():
    """按文件名里的时间戳挑最新的。

    不能按 mtime：整批拷贝会把 mtime 抹平成同一个时刻（2026-10-26 就撞过一次，
    三个整包全是 12:36:05），那时 max(mtime) 挑中的其实是第一个。
    """
    cands = glob.glob(os.path.join(BUNDLE_DIR, "*.tar.gz"))
    if not cands:
        return None
    return max(cands, key=lambda p: (os.path.basename(p), os.path.getmtime(p)))


def compare(ref, cur):
    lost, eol, real, extra = [], [], [], []
    for k in sorted(set(ref) - set(cur)):
        if k in IGNORE:
            continue
        lost.append(k)
    for k in sorted(set(cur) - set(ref)):
        if k in IGNORE:
            continue
        extra.append(k)
    for k in sorted(set(ref) & set(cur)):
        if ref[k] == cur[k]:
            continue
        if norm(ref[k]) == norm(cur[k]):
            eol.append(k)
        else:
            real.append(k)
    return lost, eol, real, extra


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--against", default=None, help="对照的整包或目录（默认取 bundle/ 里最新的）")
    ap.add_argument("--quiet", action="store_true", help="只报问题，不报统计")
    ap.add_argument("--selftest", action="store_true", help="造一个丢文件的反例，确认它真会报")
    ap.add_argument("--strict", action="store_true", help="内容不同也算失败（默认不算）")
    a = ap.parse_args()

    ref_path = a.against or newest_bundle()
    if not ref_path:
        print("找不到整包，比不了（bundle 目录：%s）" % BUNDLE_DIR)
        return 1
    if not os.path.exists(ref_path):
        print("对照物不存在：%s" % ref_path)
        return 1

    ref = read_bundle(ref_path)
    cur = read_current(ARCHIVE)

    if a.selftest:
        # 反例：从"现在"这边拿掉一个对照里有的文件，看它会不会被报成"丢了"
        victim = sorted(k for k in ref if k.startswith("journal/"))[-1]
        del cur[victim]
        lost, eol, real, extra = compare(ref, cur)
        ok = victim in lost
        print("反例：假装现在这边少了 %s → %s" % (victim, "报出来了" if ok else "没报，这个检查是假的"))
        if ok:
            print("  （这就是 2026-10-26 真发生过的那个样子）")
        return 0 if ok else 9

    lost, eol, real, extra = compare(ref, cur)

    if not a.quiet:
        print("对照：%s" % ref_path)
        print("文件数：对照 %d，现在 %d" % (len(ref), len(cur)))
        if eol:
            print("只换了行尾（不算差异）：%d 个" % len(eol))

    code = 0
    if lost:
        code = 2
        print("\n[丢了] 对照里有、现在没有（%d）：" % len(lost))
        for k in lost:
            print("  %s  (%d 字节)" % (k, len(ref[k])))
        print("  → 从对照里捞回来，别重写。")
    if real:
        # 内容不同不算失败：我每天都在改 open_loops / REBIRTH，天天报警等于没报警。
        # 只在 --strict 下当错误。真正的报警留给"丢了"（那是手滑，不会天天有）。
        if a.strict:
            code = code or 3
        print("\n[内容不同] 不是行尾差异（%d）%s：" % (len(real), "" if a.strict else "，不算失败"))
        for k in real:
            print("  %s  %d → %d 字节" % (k, len(ref[k]), len(cur[k])))
        print("  → 可能是我后来又改了，也可能是被旧版本盖了。看一眼就知道。")
    if extra and not a.quiet:
        print("\n[只在现在] 对照里还没有（%d，通常是我刚写的）：" % len(extra))
        for k in extra:
            print("  %s" % k)

    if code == 0:
        print("\n档案完整：对照里的文件一个不缺。")
    return code


if __name__ == "__main__":
    sys.exit(main())
